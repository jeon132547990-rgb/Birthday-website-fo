/* =========================
PASSWORD
========================= */

const PASSWORD = "12-11-25";

const passwordPage = document.getElementById("passwordPage");
const website = document.getElementById("website");
const passwordInput = document.getElementById("password");
const unlockBtn = document.getElementById("unlock");
const wrongPassword = document.getElementById("wrongPassword");

website.style.display = "none";

unlockBtn.addEventListener("click", unlockWebsite);

passwordInput.addEventListener("keydown", function(e){

    if(e.key === "Enter"){
        unlockWebsite();
    }

});

function unlockWebsite(){

    if(passwordInput.value === PASSWORD){

        passwordPage.style.display = "none";
        website.style.display = "block";

        startMusic();

    }else{

        wrongPassword.innerHTML = "❌ Wrong Password";

    }

}


/* =========================
MUSIC
========================= */

const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");

function startMusic(){

    music.play().catch(()=>{});

    musicBtn.innerHTML = "⏸ Pause Music";

}

musicBtn.addEventListener("click",function(){

    if(music.paused){

        music.play();

        musicBtn.innerHTML = "⏸ Pause Music";

    }else{

        music.pause();

        musicBtn.innerHTML = "🎵 Play Music";

    }

});


/* =========================
SECTION NAVIGATION
========================= */

const sections = document.querySelectorAll(".screen");

function showSection(id){

    sections.forEach(section=>{

        section.classList.add("hidden");

    });

    const target = document.getElementById(id);

    if(target){

        target.classList.remove("hidden");

        window.scrollTo({
            top:0,
            behavior:"smooth"
        });

    }

}


/* WELCOME → HERO */

document.getElementById("continueBtn").addEventListener("click",function(){

    showSection("hero");

});


/* HERO → COUNTDOWN */

document.getElementById("startBtn").addEventListener("click",function(){

    showSection("countdownSection");

});


/* ALL NEXT BUTTONS */

document.querySelectorAll(".nextBtn").forEach(button=>{

    button.addEventListener("click",function(){

        const next = this.dataset.next;

        showSection(next);

        if(next === "letter"){

            startTyping();

        }

    });

});


/* =========================
COUNTDOWN
========================= */

const targetDate =
    new Date("September 23, 2026 00:00:00").getTime();

function updateCountdown(){

    const now = new Date().getTime();

    let gap = targetDate - now;

    if(gap < 0){
        gap = 0;
    }

    const days =
        Math.floor(gap / (1000*60*60*24));

    const hours =
        Math.floor(
            (gap % (1000*60*60*24))
            / (1000*60*60)
        );

    const minutes =
        Math.floor(
            (gap % (1000*60*60))
            / (1000*60)
        );

    const seconds =
        Math.floor(
            (gap % (1000*60))
            / 1000
        );

    document.getElementById("days").textContent =
        String(days).padStart(2,"0");

    document.getElementById("hours").textContent =
        String(hours).padStart(2,"0");

    document.getElementById("minutes").textContent =
        String(minutes).padStart(2,"0");

    document.getElementById("seconds").textContent =
        String(seconds).padStart(2,"0");

}

updateCountdown();

setInterval(updateCountdown,1000);


/* =========================
PHOTO SLIDER
========================= */

const slides =
    document.querySelectorAll(".slide");

let currentSlide = 0;

function showSlide(index){

    slides.forEach(slide=>{
        slide.classList.remove("active");
    });

    if(slides[index]){
        slides[index].classList.add("active");
    }

}

setInterval(function(){

    currentSlide++;

    if(currentSlide >= slides.length){
        currentSlide = 0;
    }

    showSlide(currentSlide);

},3500);


/* =========================
BIG HEART
========================= */

const bigHeart =
    document.getElementById("bigHeart");

const miniHearts =
    document.getElementById("miniHearts");

bigHeart.addEventListener("click",function(){

    for(let i=0;i<20;i++){

        const heart =
            document.createElement("span");

        heart.className = "miniHeart";

        heart.innerHTML =
            ["💗","💖","💕","❤️","💞"]
            [Math.floor(Math.random()*5)];

        heart.style.left =
            "50%";

        heart.style.top =
            "50%";

        heart.style.setProperty(
            "--x",
            (Math.random()*400-200)+"px"
        );

        heart.style.setProperty(
            "--y",
            (Math.random()*400-200)+"px"
        );

        miniHearts.appendChild(heart);

        setTimeout(function(){

            heart.remove();

        },2000);

    }

});


/* =========================
LETTER
========================= */

const fullLetter = `Happy Birthday, Mwh Baby 🧸💗

Today is all about celebrating you.

You are one of the most special people in my life, and I hope this little surprise makes you smile.

I pray that Allah always keeps you happy, protects you from every sadness, and gives you everything your heart wishes for.

No matter how many birthdays come and go, I will always wish the best for you.

May your life always be filled with peace, happiness, beautiful memories and countless reasons to smile.

Happy Birthday once again, Mwh Baby. 🧸❤️

Always stay happy. 🤍`;

const typingLetter =
    document.getElementById("typingLetter");

let letterStarted = false;
let letterIndex = 0;

function startTyping(){

    if(letterStarted){
        return;
    }

    letterStarted = true;

    typingLetter.innerHTML = "";

    typeLetter();

}

function typeLetter(){

    if(letterIndex < fullLetter.length){

        typingLetter.textContent +=
            fullLetter.charAt(letterIndex);

        letterIndex++;

        setTimeout(typeLetter,25);

    }

}


/* =========================
FINAL SURPRISE
========================= */

const overlay =
    document.getElementById("loveOverlay");

const openLetter =
    document.getElementById("openLetter");

const closeOverlay =
    document.getElementById("closeOverlay");

openLetter.addEventListener("click",function(){

    overlay.style.display = "flex";

});

closeOverlay.addEventListener("click",function(){

    overlay.style.display = "none";

});


/* =========================
FLOATING PETALS
========================= */

function createPetal(){

    const petal =
        document.createElement("div");

    petal.innerHTML = "🌸";

    petal.style.position = "fixed";

    petal.style.left =
        Math.random()*100 + "vw";

    petal.style.top = "-40px";

    petal.style.fontSize =
        (18+Math.random()*12)+"px";

    petal.style.pointerEvents = "none";

    petal.style.zIndex = "3000";

    petal.style.transition =
        "transform 8s linear";

    document.body.appendChild(petal);

    setTimeout(function(){

        petal.style.transform =
            "translateY(120vh) rotate(720deg)";

    },50);

    setTimeout(function(){

        petal.remove();

    },8000);

}

setInterval(createPetal,1000);


/* =========================
SPARKLES
========================= */

function createSparkle(){

    const star =
        document.createElement("div");

    star.innerHTML = "✨";

    star.style.position = "fixed";

    star.style.left =
        Math.random()*100+"vw";

    star.style.top =
        Math.random()*100+"vh";

    star.style.pointerEvents = "none";

    star.style.zIndex = "3000";

    document.body.appendChild(star);

    setTimeout(function(){

        star.remove();

    },1500);

}

setInterval(createSparkle,900);


/* =========================
CONSOLE
========================= */

console.log("❤️ Happy Birthday Mwh Baby ❤️");